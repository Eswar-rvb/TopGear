
import java.util.Scanner;

public class Assig7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String S1");
		String s1 = sc.next();
		System.out.println("Enter the String S2");
		String s2=sc.next();
		
		int n = s1.length();
		int m = s2.length();
		
		char c1[]=s1.toCharArray(); //converting to charArray
		char c2[]=s2.toCharArray();
		int j=0,k=0;
		char d[] =  new char[n+m];
		
		//merging by taking one character from each string
		for(int i=0;i<m+n;i++)
		{
			if(i%2==0)
			{
				d[i]=c1[j];
				j++;
			}
			if(i%2!=0)
			{
				d[i]=c2[k];
				k++;
			}
			
		}
		String t = new String(d);
		System.out.println("Merged String");
		System.out.println(t);
		

	}

}
