

import java.util.Scanner;

public class Assig2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String T :");
		String t = sc.next();
		char []c=t.toCharArray();
		int n = t.length();
		int u=0,l=0;
		for(int i=0;i<n;i++)
		{
			//counting no of UpperCase characters
			if(c[i]>=65 && c[i]<=90)
			{
				u++;
			}
			////counting no of LowerCase characters
			if(c[i]>=97 && c[i]<=122)
			{
				l++;
			}
		}
		//if Upper and LowerCase characters are equal
		if(l==u)
		{
			System.out.println("Equally Distributed");
		}
		//if not equal printing No of Upper and LowerCase characters
		else
		{
			System.out.println("No of Lower Case letters : "+l);
			System.out.println("No of Upper Case letters : "+u);
			
		}
		sc.close();
		
	}

}
