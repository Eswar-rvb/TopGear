

import java.util.*;

public class Assig9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		char c[] = s.toLowerCase().toCharArray();
		int n = s.length();
		int k=0;
		//Sorting String Characters
		for(int i=0;i<n;i++) 
		{
			for(int j=i;j<n;j++)
			{
				if(c[i]>c[j])
				{
					char temp=c[i];
					c[i]=c[j];
					c[j]=temp;
				}
			}
		}
		//returning odd positioned elements
		System.out.println("Odd Positioned elements after sorting");
		for(int i=0;i<n;i=i+2)
		{
			System.out.print(c[i]);
		}
	}

}
