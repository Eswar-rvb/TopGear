
import java.util.Scanner;

public class Assig1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Getting Strings S and S1 from user......
		System.out.println("Enter String S :");
		String s = sc.next();
		System.out.println("Enter String S1 :");
		String s1 = sc.next();
		
		//Checking if S and S1 are equal.....
		if(s.equals(s1))
		{
			//Reverse String using StringBuilder....
			StringBuilder sb = new StringBuilder(s);
			sb = sb.reverse();
			System.out.println(sb);
		}
		else
		{
			System.out.println("Reverse Not Supported");
		}
		sc.close();
		
	}

}
