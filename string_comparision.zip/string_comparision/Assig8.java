

import java.util.ArrayList;
import java.util.*;


public class Assig8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.nextLine();
		char c[] = s.toLowerCase().toCharArray();
		int d=0,count=0,e=100;
		int max=0,min=0;
		int n= c.length;
	
		for(int i=0;i<n;i++)
		{
			count=0;
			//comparing each element with other elements, if equal count is increased
			for(int j=0;j<n;j++)
			{
				if(c[i]==c[j] && i!=j) {
					count++;
				}
			}
			//if count is more, character occurred maximum times
			if(d<=count)
			{
				d=count;
				max=i;
			}
			//if count is less, character occurred minimum times
			if(e>=count)
			{
				e=count;
				min=i;
			}
		}
		
		System.out.print("Maximum Ocuured Character is ");
		System.out.println(c[max]);
		System.out.print("Minimum Ocuured Character is ");
		System.out.println(c[min]);

	}

}
