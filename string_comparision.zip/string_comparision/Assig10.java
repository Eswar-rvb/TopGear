

import java.util.Scanner;

public class Assig10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String");
		String s = sc.next();
		int n = s.length();
		
		//converting last char of string to uppercase and storing it in c
		char c= s.toUpperCase().charAt(n-1);
		
		// Alphabetical index is calculated 
		int index = (int)c-64;
		System.out.println("Age of String is ");
		System.out.println(index+n);

	}

}
