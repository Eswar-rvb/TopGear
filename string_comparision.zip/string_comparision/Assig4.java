
import java.util.Scanner;

public class Assig4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String :");
		String s = sc.nextLine();
		
		//splits strings based on white-spaces
		String []a=s.split(" ");
		int n = a.length;
		int d=100,l=0,c=0;
		
		//arranging them in dictionary order
		for(int i=0;i<n;i++)
		{
			for(int j=i;j<n;j++)
			{
				if(a[i].compareTo(a[j])>0)
				{
					  String temp = a[i];
	                    a[i] = a[j];
	                    a[j] = temp;
				}
			}
		}
		
		//splited using white and arranging them in dictionary order
		for(int i=0;i<n;i++)
		{
			System.out.println(a[i]);
		}
		

	}

}