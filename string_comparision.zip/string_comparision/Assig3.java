

import java.util.Scanner;

public class Assig3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String :");
		String s = sc.nextLine();
		String []a=s.split(" ");  //Splitting Spring based on white-spaces
		int n = a.length;
		int d=100,l=0,c=0;
		for(int i=0;i<n;i++)
		{
			l=a[i].length();
			//Finding the string with smallest length
			if(d>=l)
			{
				d=l;
				c=i;
			}
		}
		System.out.println("String with the smallest length is :");
		System.out.println(a[c]);

	}

}
