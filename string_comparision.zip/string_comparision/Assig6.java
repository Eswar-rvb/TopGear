
import java.util.Scanner;

public class Assig6 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		
		 //Get String from User.....
		 System.out.println("Enter the String");
		 String s = sc.next();
		 int d=1; // Rotation to be performed is set to one...
		 
		 String a,b,c="";
		 
		 int n = s.length();   //Length of the String..
		 
		 //if length is even performing Clockwise rotation - Right rotation......
		 if(n%2==0)
		 {
			 a = s.substring(n-d,n);
			 b = s.substring(0,n-d);
			 c = a+b;
			 System.out.println("Even Length - Performing Clockwise rotation by 1");
			 System.out.println(c);
		 }
		 
		//if length is odd performing Anti-clockwise rotation - Left rotation......
		 if(n%2!=0)
		 {
			 a = s.substring(0,d);
			 b = s.substring(d,n);
			 c = b+a;
			 System.out.println("Odd Length - Performing AntiClockwise rotation by 1");
			 System.out.println(c);
		 }
		 
		 

	}

}
