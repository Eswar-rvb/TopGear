

import java.util.Scanner;

public class Assig5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String :");
		String s = sc.next();
		char c[] = s.toCharArray();
		int n = s.length();
		for(int i=0;i<n;i++)
		{
			//toggling from uppercase to lowercase
			if(c[i]>=65 && c[i]<=91)
			{
				c[i]=(char) (c[i]+32);
			}
			
			//toggling from Lowercase to Uppercase
			else if(c[i]>=97 && c[i]<=122)
			{
				c[i]=(char) (c[i]-32);
			}
		}
		System.out.println("Toggled String : ");
		for(char d:c)
		{
			System.out.print(d);

		}
		
	}

}
